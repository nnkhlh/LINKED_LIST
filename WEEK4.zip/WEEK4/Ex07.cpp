#include <iostream>
#include <fstream>
using namespace std;

int* readBinaryFile(const string &filename, int &n) {
    ifstream fin(filename, ios::binary);
    if(!fin) {
        cout << "Cannot open file!" << endl;
        return NULL;
    }
    fin.read((char*)(&n), sizeof(n));
    int *a = new int[n];
    fin.read((char*)(a), n * sizeof(int));
    fin.close();
    return a;
}

struct Node{
    int data;
    Node* next;
};

void insertNode(Node* &head, int data){
    Node* newNode = new Node{data, NULL};
    if(!head) {
        head = newNode;
        return;
    }
    Node* temp = head;
    while(temp->next) {
        temp = temp->next;
    }
    temp->next = newNode;
}

Node* getMiddle(Node* head){
    if(!head || !head->next) return head;
    Node* slow = head;
    Node* fast = head->next;
    while(fast && fast->next){
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}


Node* mergeLL(Node* left, Node* right, int &cnt) {
    if(!left) return right;
    if(!right) return left;
    Node* res = NULL;
    cnt++;
    if(left->data <= right->data) {
        res = left;
        res->next = mergeLL(left->next, right, cnt);
    } else {
        res = right;
        res->next = mergeLL(left, right->next, cnt);
    }
    return res;
}

Node* mergeSortList(Node* &head, int &cnt) {
    if(!head || !head->next) return head;
    Node* mid = getMiddle(head);
    Node* half = mid->next;
    mid->next = NULL;
    Node* left = mergeSortList(head, cnt);
    Node* right = mergeSortList(half, cnt);
    return mergeLL(left, right, cnt);
}

void printArray(Node* head) {
    Node* temp = head;
    while(temp) {
        cout << temp->data << "->";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

int main() {
    int n;
    int *a = readBinaryFile("10000n_LE.bin", n);
    Node* head = NULL;
    if(a) {
        //cout << "Number of elements: " << n << endl;
        for(int i = 0; i < n; i++) {
            insertNode(head, a[i]);
        }
    }
    int cnt = 0;
    mergeSortList(head,cnt);
    cout << "MergeSort comparisons: " << cnt << endl;
    //printArray(head);
    return 0;
}
