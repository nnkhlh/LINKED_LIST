#include <iostream>
#include <time.h>
using namespace std;

void bubbleSort(int *a, int n) {
    for (bool isswap = true; isswap; --n) {
        isswap = false;
        for (int i = 0; i < n - 1; i++) {
            if(a[i] > a[i + 1]) {
                swap(a[i], a[i + 1]);
                isswap = true;
            }
        }
    }
}
void comb_sort(int *a, int n){
    int gap = n;
    float ratio = 1.3f;

    for (bool isswap = true; isswap; ) {
        gap /= ratio;
        if (gap < 1) {
            gap = 1;
            isswap = false;
        } else if(gap == 9 || gap == 10) {
            gap = 11;
        }
        for (int i = 0; i + gap < n; i++) {
            if(a[i] > a[i + gap]) {
                swap(a[i], a[i + gap]);
                isswap = true;
            }
        }

    }
}

void selectionSort(int *a, int n) {
    for(int i = 0; i < n - 1; i++) {
        int temp = i;
        for (int j = i + 1; j < n; j++) {
            if(a[j] < a[temp]) {
                temp = j;
            }
        }
        swap(a[i], a[temp]);
    }
}

void insertionSort(int *a, int n) {
    for (int i = 1; i < n; i++) {
        int x = a[i];
        int temp = i - 1;
        while (temp >= 0 && x < a[temp]) {
            a[temp + 1] = a[temp];
            temp--;
        }
        a[temp + 1] = x;
    }
}

void mergeArray(int na, int *a, int nb, int *b, int *c) {
    int i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        if(a[i] <= b[j]) c[k++] = a[i++];
        else if(a[i] > b[j]) c[k++] = b[j++];
    }
     while (i < na) {
        c[k++] = a[i++];
     }
     while (j < nb) {
        c[k++] = b[j++];
     }
}
void mergeSort(int *a, int n, int *buff, int cutoff) {
    if (n <= cutoff) {
        insertionSort(a, n);
        return;
    }
    int half = n / 2;
    mergeSort(a, half, buff, cutoff);
    mergeSort(a + half, n - half, buff + half, cutoff);
    mergeArray(half, a, n - half, a + half, buff);
    copy(buff, buff + n, a);
}

int partition_array(int *a, int L, int R, int pivot) {
    int i = L, j = R;
    while (i <= j) {
        while (a[i] < pivot) i++;
        while (a[j] > pivot) j--;
        if (i <= j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    return i;
}

void quick_sort(int *a, int L, int R) {
    if (L >= R) return;
    int pivot = a[L + (R - L) / 2];
    int partitionIndex = partition_array(a, L, R, pivot);
    quick_sort(a, L, partitionIndex - 1);
    quick_sort(a, partitionIndex + 1, R);
}

void printArray(int *a, int n) {
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
}

int main() {
    srand(time(0));

    int n = 1 + rand() % 50;

    int *originalArr = new int[n];
    int *arr = new int[n];
    int *buff = new int[n];

    for (int i = 0; i < n; i++) {
        originalArr[i] = rand() % 1000;
    }

    cout << "\nMang ngau nhien ban dau: ";
    printArray(originalArr, n);

    copy(originalArr, originalArr + n, arr);
    cout << "\nBubble Sort:\n";
    bubbleSort(arr, n);
    printArray(arr, n);

    copy(originalArr, originalArr + n, arr);
    cout << "\nSelection Sort:\n";
    selectionSort(arr, n);
    printArray(arr, n);

    copy(originalArr, originalArr + n, arr);
    cout << "\nInsertion Sort:\n";
    insertionSort(arr, n);
    printArray(arr, n);

    copy(originalArr, originalArr + n, arr);
    cout << "\nMerge Sort:\n";
    copy(arr, arr + n, buff);
    mergeSort(buff, n, arr, 4);
    copy(buff, buff + n, arr);
    printArray(arr, n);

    copy(originalArr, originalArr + n, arr);
    cout << "\nComb Sort:\n";
    comb_sort(arr, n);
    printArray(arr, n);

    copy(originalArr, originalArr + n, arr);
    cout << "\nQuick Sort:\n";
    quick_sort(arr, 0, n - 1);
    printArray(arr, n);

    delete[] originalArr;
    delete[] arr;
    delete[] buff;

    return 0;
}
