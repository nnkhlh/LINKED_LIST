#include <iostream>
#include <time.h>
using namespace std;

int cmp1(int a, int b) {
    return a - b;
}

int cmp2(int a, int b) {
    return b - a;
}
/*
bubble sort:
đẩy phần tử lớn nhất về cuối dãy bằng cách hoán đổi vị trí hai phần tử liền kề nếu chúng sai thứ tự
*/
void bubbleSort(int *a, int n, int (*cmp)(int, int)){
    /*for(bool isSwap = true; isSwap; --n) {
        isSwap = false;
        for(int i = 0; i < n - 1; i++) {
            if(a[i] > a[i + 1]) {
                swap(a[i], a[i + 1]);
                isSwap = true;
            }
        }
    }*/
    bool isSwap;
    for(int i = 0; i < n - 1; i++) {
        for(int j = 0; j < n - i - 1; j++) {
            if(cmp(a[j], a[j + 1]) > 0) {
                swap(a[j], a[j + 1]);
                isSwap = true;
            }
            if(!isSwap) break;
        }
    }
}
/*
selection sort:
tìm phần tử nhỏ nhất và đặt vào đúng vị trí, bằng cách hoán đổi với phần tử đầu tiên
*/
void selectionSort(int *a, int n, int(*cmp)(int, int)){
    for(int i = 0; i < n - 1; i++) {
        int vitrimin = i;
        for(int j = i; j < n; j++) {
            if(cmp(a[j], a[vitrimin]) < 0){
                vitrimin = j;
            }
        }
        swap(a[i], a[vitrimin]);
    }
}

/*
insertion sort:

*/

void insertionSort(int *a, int n) {
    for(int i = 1; i < n; i++) {
        int x = a[i];
        int vitrichen = i - 1;
        while (vitrichen >= 0 && x < a[vitrichen]) {
            a[vitrichen + 1] = a[vitrichen];
            vitrichen--;
        }
        a[vitrichen + 1] = x;
    }
}

void merge(int *a, int na, int *b, int nb, int *c) {
    int i = 0, j = 0, k = 0;
    while (i < na && j < nb) {
        if(a[i] <= b[j]) c[k++] = a[i++];
        else c[k++] = b[j++];
    }
    while (i < na) c[k++] = a[i++];
    while (j < nb) c[k++] = b[j++];
}
/*
void mergeSort(int *a , int n, int *buff, int cutoff) {
    //buff mảng phụ để lưu kết quả sau khi merge
    if(n <= cutoff) {
        insertionSort(a, n);
        return;
    }
    int half = n / 2;
    mergeSort(a, half, buff, cutoff);
    mergeSort(a + half, n - half, buff + half, cutoff);
    merge(a, half, a + half, n - half, buff);
    copy(buff, buff + n, a);
}*/

void mergeSort(int *a, int n, int *buff, int cutoff) {
    if(n <= cutoff) {
        insertionSort(a, n);
        return;
    }
    int half = n / 2;
    mergeSort(a, half, buff, cutoff);
    mergeSort(a + half, n - half, buff, cutoff);
    merge(a, half, a + half, n - half, buff);
    copy(buff, buff + n, a);
}


/*
lấy đại một cái pivot nào đó, sau đó lấy đúng vị trí của nó  rồi sau nó sắp trái phải
*/
int partitionArray(int *a, int left, int right, int pivot) {
    int i = left, j = right;
    while(i <= j) {
        while(a[i] < pivot) i++;
        while(a[j] > pivot) j--;
        if(i <= j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
}

void quickSort(int *a, int left, int right) {
    if(left >= right) return;
    int pivot = a[left + (right - left) / 2];
    int index = partitionArray(a, left, right, pivot);
    quickSort(a, left, index - 1);
    quickSort(a, index, right);
}


void printArray(int *a, int n) {
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
}
int main() {
    srand(time(0));

    int n = 1 + rand() % 50;

    int *originalArr = new int[n];
    int *arr = new int[n];
    int *buff = new int[n];

    for (int i = 0; i < n; i++) {
        originalArr[i] = rand() % 1000;
    }
    printArray(originalArr, n);
    copy(originalArr, originalArr + n, arr);
    cout << "\nMerge Sort:\n";
    selectionSort(arr, n, cmp1);
    printArray(arr, n);
    delete[] originalArr;
    delete[] arr;
    delete[] buff;
}
