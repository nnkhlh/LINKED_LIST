#include <iostream>
#include <time.h>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* createNode(int data) {
    Node* newNode = new Node;
    newNode->data = data;
    newNode->next = nullptr;
    return newNode;
}

void freeList(Node*& head) {
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

void insertNode(Node* &head, int data){
    Node* newNode = createNode(data);
    newNode->next = head;
    head = newNode;
}

Node* insertionSortList(Node* &head) {
    if(!head || !head->next) {
        return head;
    }
    Node dummy = {0, NULL};
    Node* sorted = &dummy;
    Node* curr = head;

    while(curr) {
        Node* nextNode = curr->next;
        //lưu trữ node tiếp theo trước khi thay đổi
        Node* prev = &dummy;
        //tìm vị trí chèn node hiện tại vào danh sách sorted
        while(prev->next && prev->next->data < curr->data) {
            prev = prev->next;
        }
        //chèn node prev->next vào sorted
        curr->next = prev->next;
        prev->next = curr;
        curr = nextNode;
    }
    return dummy.next;
}
/*
Cần chia danh sách làm hai phần → Sử dụng slow & fast pointer để tìm điểm giữa.
Sắp xếp hai phần → Gọi đệ quy mergeSort() cho từng nửa danh sách.
Hợp nhất hai danh sách đã sắp xếp → Sử dụng hàm merge().
*/

//tìm phần giữa danh sách
Node* getMiddleNode(Node* head) {
    if(!head || !head->next) return head;
    Node* fast = head->next;
    Node* slow = head;
    while(fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}
Node* merge(Node* left, Node* right) {
    if(!left) return right;
    if(!right) return left;
    Node* res = NULL;
    if(left->data <= right->data){
        res = left;
        res->next = merge(left->next, right);
    } else {
        res = right;
        res->next = merge(left, right->next);
    }
    return res;
}
//sắp xếp 2 nửa danh sách
Node* mergeSortList(Node* &head) {
    if(!head || !head->next) return head;
    Node* middle = getMiddleNode(head);
    Node* halfRight = middle->next;
    middle->next = NULL;

    Node* left = mergeSortList(head);
    Node* right = mergeSortList(halfRight);

    return merge(left, right);
}


void printList(Node* head){
    while (head) {
        cout << head->data << "->";
        head = head->next;
    }
    cout <<"NULL" << endl;
}
Node* generateValue(int minSize, int maxSize, int minValue, int maxValue) {
    int size = minSize + rand() % (maxSize - minSize + 1);
    Node *L = NULL;
    for (int i = 0; i < size; i++) {
        int val = minValue + rand() % (maxValue - minValue + 1);
        insertNode(L, val);
    }
    return L;
}

int main() {
    Node* head1 = generateValue(1, 50, 0, 1000);
    Node* head2 = generateValue(1, 50, 0, 1000);

    cout << "Original Singly Linked List:\n";
    printList(head1);
    cout << "\nInsertion sort on Singly Linked List:\n";
    head1 = insertionSortList(head1);
    printList(head1);

    cout << "\nOriginal Singly Linked List:\n";
    printList(head2);
    cout << "\nMerge sort on Singly Linked List:\n";
    head2 = mergeSortList(head2);
    printList(head2);

    freeList(head1);
    freeList(head2);
    return 0;
}
