#include "Ex02.h"

long bubbleSort(int a[], const int n, int (*cmp)(int, int)) {
    long comparisons = 0;
    bool swapped;
    for (int i = 0; i < n - 1; i++) {
        swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            comparisons++;
            if (cmp(a[j], a[j + 1]) > 0) {
                swap(a[j], a[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
    return comparisons;
}

int bubbleSortList(Node *head, int (*cmp)(int, int)) {
    if (!head) return 0;
    int comparisons = 0;
    bool swapped;
    for (Node* i = head; i != NULL; i = i->next) {
        swapped = false;
        Node* ptr1 = head;
        for (Node* j = ptr1; j->next != NULL; j = j->next) {
            comparisons++;
            if (cmp(j->data, j->next->data) > 0) {
                swap(j->data, j->next->data);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
    return comparisons;
}

void insertNode(Node* &head, int val) {
    Node* newNode = new Node{val, head};
    head = newNode;
}

void printList(Node *head) {
    while (head) {
        cout << head->data << ' ';
        head = head->next;
    }
    cout << endl;
}

void printArray(int *a, int n) {
    for (int i = 0; i < n - 1; i++) {
        cout << a[i] << ' ';
    }
    cout << a[n - 1] << endl;
}

int cmp1(int a, int b) {
    return a - b;
}

int cmp2(int a, int b) {
    return b - a;
}

