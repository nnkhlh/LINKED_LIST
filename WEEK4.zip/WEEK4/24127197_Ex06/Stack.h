#pragma once
#include"List.h"

template<class T>
struct Stack{
    List<T> *data;
};

template<class T>
Stack<T>* CreateStack(){
    Stack<T> *s = new Stack<T>;
    s->data = CreateList<T>();
    return s;
}

template<class T>
T S_Pop(Stack<T> *s){
    Node<T> *node = RemoveHead(s->data);
    T v = node->data;
    delete node;
    return v;
}

template<class T>
void S_Push(Stack<T> *s, const T &v){
    AddHead(s->data, v);
}

template<class T>
bool S_IsEmpty(Stack<T> *s){
    return s->data->pHead == NULL;
}
