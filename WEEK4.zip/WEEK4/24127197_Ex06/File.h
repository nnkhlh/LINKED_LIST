#pragma once
#include <string.h>
#include "List.h"
#include "Stack.h"

#define SLEN 31

// 🔹 Cấu trúc tập tin
struct File {
    char name[SLEN];  // Tên tập tin
    long size;         // Dung lượng tập tin
};

// 🔹 Cấu trúc thư mục
struct Directory {
    char name[SLEN];         // Tên thư mục
    List<File>* files;       // Danh sách tập tin trong thư mục
    List<Directory>* directories;  // Danh sách thư mục con
};

// 🔹 Hàm khởi tạo thư mục
Directory* InitializeDirectory(const char* name) {
    Directory* dir = new Directory;
    strncpy(dir->name, name, SLEN);
    dir->files = CreateList<File>();
    dir->directories = CreateList<Directory>();
    return dir;
}

// 🔹 Hàm khởi tạo tập tin
File* InitializeFile(const char* name, long size) {
    File* file = new File;
    strncpy(file->name, name, SLEN);
    file->size = size;
    return file;
}

// 🔹 Thêm tập tin vào thư mục
void AddFile(Directory* dir, const char* name, long size) {
    File* file = InitializeFile(name, size);
    AddTail(dir->files, *file);
}

// 🔹 Thêm thư mục con vào thư mục cha
void AddSubdirectory(Directory* parent, const char* name) {
    Directory* subDir = InitializeDirectory(name);
    AddTail(parent->directories, *subDir);
}

// 🔹 Tính tổng dung lượng thư mục (Dùng đệ quy)
long GetSizeOfDirectory(Directory* dir) {
    long totalSize = 0;

    // Tính tổng dung lượng các tập tin trong thư mục
    for (Node<File>* p = dir->files->pHead; p != NULL; p = p->pNext) {
        totalSize += p->data.size;
    }

    // Gọi đệ quy để tính dung lượng của tất cả thư mục con
    for (Node<Directory>* p = dir->directories->pHead; p != NULL; p = p->pNext) {
        totalSize += GetSizeOfDirectory(&p->data);
    }

    return totalSize;
}

// 🔹 Tính tổng dung lượng thư mục (Không đệ quy - dùng Stack)
long GetSizeOfDirectoryNR(Directory* root) {
    long totalSize = 0;
    Stack<Directory*>* stack = CreateStack<Directory*>();

    S_Push(stack, root);

    while (!S_IsEmpty(stack)) {
        Directory* currentDir = S_Pop(stack);

        // Cộng tổng dung lượng các tập tin trong thư mục hiện tại
        for (Node<File>* p = currentDir->files->pHead; p != NULL; p = p->pNext) {
            totalSize += p->data.size;
        }

        // Đưa tất cả thư mục con vào stack
        for (Node<Directory>* p = currentDir->directories->pHead; p != NULL; p = p->pNext) {
            S_Push(stack, &p->data);
        }
    }

    delete stack;
    return totalSize;
}
