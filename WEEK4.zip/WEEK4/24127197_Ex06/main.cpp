#include <iostream>
#include "Stack.h"
#include "File.h"

using namespace std;

int main() {
    cout << "==== PROGRAM TESTING ====" << endl;

    // 1️⃣ Create the root directory
    Directory* root = InitializeDirectory("Root");

    // 2️⃣ Add files to the root directory
    AddFile(root, "File1.txt", 100);
    AddFile(root, "File2.txt", 200);

    cout << "Added File1.txt (100 bytes) & File2.txt (200 bytes) to Root\n";

    // 3️⃣ Add subdirectories to the root directory
    AddSubdirectory(root, "Subfolder1");
    AddSubdirectory(root, "Subfolder2");

    cout << "Added Subfolder1 & Subfolder2 to Root\n";

    // 4️⃣ Retrieve the first subdirectory (Subfolder1) and add files to it
    Node<Directory>* sub1 = root->directories->pHead;
    AddFile(&sub1->data, "SubFile1.txt", 50);
    AddFile(&sub1->data, "SubFile2.txt", 75);

    cout << "Added SubFile1.txt (50 bytes) & SubFile2.txt (75 bytes) to Subfolder1\n";

    // 5️⃣ Calculate the total directory size using recursion
    cout << "Directory Size (Recursive): " << GetSizeOfDirectory(root) << " bytes\n";

    // 6️⃣ Calculate the total directory size using an iterative approach (without recursion)
    cout << "Directory Size (Non-Recursive): " << GetSizeOfDirectoryNR(root) << " bytes\n";

    return 0;
}
