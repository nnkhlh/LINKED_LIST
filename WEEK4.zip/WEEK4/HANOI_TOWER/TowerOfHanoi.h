#pragma once
#include <iostream>
#include "Stack.h"

using namespace std;

// 🔹 Hàm đệ quy giải bài toán Tháp Hà Nội
void TowerOfHanoi_Recursive(int n, char source, char auxiliary, char destination) {
    if (n == 1) {
        cout << "Move disk 1 from " << source << " to " << destination << endl;
        return;
    }

    // Bước 1: Di chuyển n-1 đĩa từ A -> B (C làm trung gian)
    TowerOfHanoi_Recursive(n - 1, source, destination, auxiliary);

    // Bước 2: Di chuyển đĩa lớn nhất từ A -> C
    cout << "Move disk " << n << " from " << source << " to " << destination << endl;

    // Bước 3: Di chuyển n-1 đĩa từ B -> C (A làm trung gian)
    TowerOfHanoi_Recursive(n - 1, auxiliary, source, destination);
}

// 🔹 Cấu trúc lưu thông tin di chuyển
struct Move {
    int disk;
    char from, to;
    char aux; // Thêm cọc trung gian
};


// 🔹 Giải bài toán Tháp Hà Nội bằng ngăn xếp (Không đệ quy)
/*void TowerOfHanoi_NonRecursive(int n, char A, char B, char C) {
    Stack<Move>* stack = CreateStack<Move>();

    // Bắt đầu bằng việc đẩy trạng thái đầu tiên
    S_Push(stack, {n, A, C});

    while (!S_IsEmpty(stack)) {
        Move current = S_Pop(stack);

        if (current.disk == 1) {
            cout << "Move disk 1 from " << current.from << " to " << current.to << endl;
        } else {
            // Bước 3: Di chuyển n-1 đĩa từ B -> C (A làm trung gian)
            S_Push(stack, {current.disk - 1, B, C});

            // Bước 2: Di chuyển đĩa lớn nhất từ A -> C
            cout << "Move disk " << current.disk << " from " << current.from << " to " << current.to << endl;

            // Bước 1: Di chuyển n-1 đĩa từ A -> B (C làm trung gian)
            S_Push(stack, {current.disk - 1, A, B});
        }
    }
    delete stack;
}*/

void TowerOfHanoi_NonRecursive(int n, char A, char B, char C) {
    Stack<Move>* stack = CreateStack<Move>();

    // Đẩy trạng thái đầu tiên vào stack (di chuyển n đĩa từ A -> C)
    Move firstMove = {n, A, C, B};
    S_Push(stack, firstMove);

    while (!S_IsEmpty(stack)) {
        Move current = S_Pop(stack);

        if (current.disk == 1) {
            cout << "Move disk 1 from " << current.from << " to " << current.to << endl;
        } else {
            // Bước 3: Di chuyển n-1 đĩa từ `aux` -> `to` (sử dụng `from` làm trung gian)
            Move move3 = {current.disk - 1, current.aux, current.to, current.from};
            S_Push(stack, move3);

            // Bước 2: Di chuyển đĩa lớn nhất từ `from` -> `to`
            cout << "Move disk " << current.disk << " from " << current.from << " to " << current.to << endl;

            // Bước 1: Di chuyển n-1 đĩa từ `from` -> `aux` (sử dụng `to` làm trung gian)
            Move move1 = {current.disk - 1, current.from, current.aux, current.to};
            S_Push(stack, move1);
        }
    }
    delete stack;
}
