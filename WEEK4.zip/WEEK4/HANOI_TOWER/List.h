#pragma once
template <class T>
struct Node{
    T data;
    Node *pNext;
};

template <class T>
struct List{
    Node<T> *pHead, *pTail;
};

template <class T>
Node<T>* CreateNode(const T& value) {
    Node<T> *node = new Node<T>;
    node->data = value;
    node->pNext = NULL;
    return node;
}

template <class T>
List<T>* CreateList() {
    List<T> *list = new List<T>;
    list->pHead = list->pTail = NULL;
    return list;
}

template <class T>
void AddHead(List<T> *l, const T &value) {
    Node<T> *node = CreateNode(value);
    if(l->pHead == NULL) {
        l->pHead = l->pTail = node;
        return;
    }
    node->pNext = l->pHead;
    l->pHead = node;
}

template <class T>
void AddTail(List<T> *l, const T &value) {
    Node<T> *node = CreateNode(value);
    if(l->pHead == NULL) {
        l->pHead = l->pTail = node;
        return;
    }
    l->pTail->pNext = node;
    l->pTail = node;
}

template <class T>
Node<T> *RemoveHead(List<T> *l) {
    Node<T> *node = NULL;
    if(l->pHead == NULL) {
        return node;
    }
    node = l->pHead;
    if(l->pTail == node) {
        l->pHead = l->pTail = NULL;
    } else {
        l->pHead = node->pNext;
    }
    node->pNext = NULL;
    return node;
}

template <class T>
void ClearList(List<T> *l){
    Node<T> *node = NULL;
    do{
        if (node != NULL){
            delete node;
        }
        node = RemoveHead(l);
    } while (node != NULL);
}

template <class T>
void ConcatList(List<T> *lD, List<T> *lS){
    if (lS->pHead == NULL){
        return;
    }
    if (lD->pTail == NULL){
        lD->pHead = lS->pHead;
        lD->pTail = lS->pTail;
        return;
    }
    lD->pTail->pNext = lS->pHead;
    lD->pTail = lS->pTail;
}




