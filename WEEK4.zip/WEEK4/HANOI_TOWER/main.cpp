#include <iostream>
#include "TowerOfHanoi.h"

using namespace std;

int main() {
    int n;

    cout << "Enter number of disks: ";
    cin >> n;

    cout << "\nRecursive Solution:\n";
    TowerOfHanoi_Recursive(n, 'A', 'B', 'C');

    cout << "\nNon-Recursive Solution:\n";
    TowerOfHanoi_NonRecursive(n, 'A', 'B', 'C');

    return 0;
}
