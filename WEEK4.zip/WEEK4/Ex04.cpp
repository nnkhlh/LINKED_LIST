#include <iostream>
#include <fstream>
#include <time.h>
using namespace std;

void insertionSort(int *&a, int n, int &cnt, int (*cmp)(int, int)) {
    for(int i = 1; i < n; i++) {
        int x = a[i];
        int vitrichen = i - 1;
        while (vitrichen >= 0 && cmp(a[vitrichen], x) > 0){
            cnt++;
            a[vitrichen + 1] = a[vitrichen];
            vitrichen--;
        }
        a[vitrichen + 1] = x;
    }
}

int cmp1(int a, int b){
    return a - b;
}
int cmp2(int a, int b) {
    return b - a;
}

void printArray(int *a, int n) {
    for(int i = 0; i < n; i++) {
        cout << a[i] << ' ';
    }
}

struct Node{
    int data;
    Node* next;
};

void insertNode(Node* &head, int data) {
    Node* newNode = new Node{data, NULL};
    if(!head) {
        head = newNode;
        return;
    }
    Node* temp = head;
    while(temp->next){
        temp = temp->next;
    }
    temp->next = newNode;
}

void printLL(Node* head){
    Node* temp = head;
    while(temp){
        cout << temp->data << "->";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

Node* insertionSortList(Node* head, int &cnt) {
    if(!head || !head->next) return head;
    Node dummy;
    dummy.next = nullptr;
    Node* sorted = &dummy;
    Node* curr = head;
    while(curr){

        Node* nextNode = curr->next;
        Node*  prev = &dummy;
        while(prev->next && prev->next->data < curr->data) {
            cnt++;
            prev = prev->next;
        }
        curr->next = prev->next;
        prev->next = curr;
        curr = nextNode;
    }
    return dummy.next;
}
int main() {
    srand(time(0));
    int n = 50;
    int *a = new int[n];
    for (int i = 0; i < n; i++) {
        a[i] = 1 + rand() % 1000;
    }

    int cnt1 = 0;
    insertionSort(a, n, cnt1, cmp1);
    cout << "Comparisons in Array Sort: " << cnt1 << endl;
    cout << "Ascending order: " << endl;
    printArray(a, n);

    cnt1 = 0;
    insertionSort(a, n, cnt1, cmp2);
    cout << "\nDeascending order: " << endl;
    printArray(a, n);

    Node* head = NULL;
    for (int i = 0; i < n; i++) {
        insertNode(head, 1 + rand() % 1000);
    }
    int cnt2 = 0;
    Node* newList = insertionSortList(head, cnt2);
    cout << "\n\nComparisons in Linked List Sort: " << cnt2 << endl;

    delete []a;
    return 0;
}
