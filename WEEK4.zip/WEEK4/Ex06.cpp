#include <iostream>
#include <fstream>
using namespace std;

int* readBinaryFile(const string &filename, int &n) {
    ifstream fin(filename, ios::binary);
    if(!fin){
        cout << "Cannot open file!" << endl;
        return NULL;
    }
    fin.read((char*)(&n), sizeof(n));
    int *a = new int[n];
    fin.read((char*)(a), n * sizeof(int));
    fin.close();
    return a;
}

void merge1(int *a, int na, int *b, int nb, int* c, int &cnt){
    int i = 0, j = 0, k = 0;
    while(i < na && j < nb) {
        cnt++;
        if(a[i] <= b[j]) c[k++] = a[i++];
        else c[k++] = b[j++];
    }
    while(i < na) c[k++] = a[i++];
    while(j < nb) c[k++] = b[j++];
}

void mergeSort1(int *a, int n, int *buff, int &cnt) {
    if(n <= 1) return;
    int half =  n / 2;
    mergeSort1(a, half, buff, cnt);
    mergeSort1(a + half, n - half, buff, cnt);
    merge1(a, half, a + half, n - half, buff, cnt);
    copy(buff, buff + n, a);
}

void merge2(int *a, int start, int mid, int end, int &cnt) {
    int *res = new int[end - start + 1];
    int i = start, j = mid + 1, k = 0;

    while(i <= mid && j <= end) {
        cnt++;
        if(a[i] <= a[j]) res[k++] = a[i++];
        else res[k++] = a[j++];
    }
    while(i <= mid) res[k++] = a[i++];
    while(j <= end) res[k++] = a[j++];
    copy(res, res + k, a + start);
    delete []res;
}

void mergeSort2(int *a, int n, int &cnt){
    if(n <= 1) return;
    for (int i = 1; i <= n; i *= 2){
        for(int j = 0; j < n - 1; j += 2 * i) {
            int mid = j + i - 1;
            int end = min(j + 2 * i - 1, n - 1);
            if(mid < end){
                merge2(a, j, mid, end, cnt);
            }
        }
    }
}
int main() {
    int n;
    int *a1 = readBinaryFile("10000n_LE.bin", n);
    int cnt1 = 0, cnt2 = 0;
    int *buff = new int[n];
    mergeSort1(a1, n, buff, cnt1);
    cout << "Merge Sort (Recursive) comparisons: " << cnt1 << endl;

    int *a2 = readBinaryFile("10000n_LE.bin", n);
    mergeSort2(a2, n, cnt2);
    cout << "Merge Sort (No recursive) comparisons: " << cnt2 << endl;
    delete []a1;
    delete []a2;
    delete []buff;
    return 0;
}
