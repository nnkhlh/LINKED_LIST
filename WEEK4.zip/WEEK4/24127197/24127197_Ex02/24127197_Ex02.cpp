#include "Ex02.h"

int main() {
    srand(time(0));
    const int SIZE = 50;
    int arr[SIZE];

    for (int i = 0; i < SIZE; i++) {
        arr[i] = rand() % 1000 + 1;
    }

    Node* head = nullptr;
    for (int i = 0; i < SIZE; i++) {
        insertNode(head, arr[i]);
    }

    cout << "Original Array: " << endl;
    printArray(arr, SIZE);

    long cmpArrayAsc = bubbleSort(arr, SIZE, cmp1);
    cout << "\nArray sorted in ascending order: " << endl;
    printArray(arr, SIZE);
    cout << "Number of comparisons: " << cmpArrayAsc << endl;

    long cmpArrayDesc = bubbleSort(arr, SIZE, cmp2);
    cout << "\nArray sorted in descending order: " << endl;
    printArray(arr, SIZE);
    cout << "Number of comparisons: " << cmpArrayDesc << endl;

    cout << "\nOriginal Linked List: " << endl;
    printList(head);

    int cmpListAsc = bubbleSortList(head, cmp1);
    cout << "\nLinked List sorted in ascending order: " << endl;
    printList(head);
    cout << "Number of comparisons: " << cmpListAsc << endl;

    int cmpListDesc = bubbleSortList(head, cmp2);
    cout << "\nLinked List sorted in descending order: " << endl;
    printList(head);
    cout << "Number of comparisons: " << cmpListDesc << endl;

    return 0;
}
