#ifndef EX04_H
#define EX04_H

#include <iostream>
#include <fstream>
#include <time.h>
using namespace std;

struct Node{
    int data;
    Node* next;
};

void insertionSort(int *&a, int n, int &cnt, int (*cmp)(int, int));
void printArray(int *a, int n);
void insertNode(Node* &head, int data);
void printLL(Node* head);
Node* insertionSortList(Node* head, int &cnt, int (*cmp)(int, int));
int cmp1(int a, int b);
int cmp2(int a, int b);

#endif // EX04_H
