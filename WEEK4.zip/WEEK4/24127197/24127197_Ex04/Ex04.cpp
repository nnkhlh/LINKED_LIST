#include "Ex04.h"
using namespace std;

void insertionSort(int *&a, int n, int &cnt, int (*cmp)(int, int)) {
    for(int i = 1; i < n; i++) {
        int x = a[i];
        int vitrichen = i - 1;
        while (vitrichen >= 0 && cmp(a[vitrichen], x) > 0){
            cnt++;
            a[vitrichen + 1] = a[vitrichen];
            vitrichen--;
        }
        a[vitrichen + 1] = x;
    }
}

int cmp1(int a, int b){
    return a - b;
}
int cmp2(int a, int b) {
    return b - a;
}

void printArray(int *a, int n) {
    for(int i = 0; i < n; i++) {
        cout << a[i] << ' ';
    }
}

void insertNode(Node* &head, int data) {
    Node* newNode = new Node{data, NULL};
    if(!head) {
        head = newNode;
        return;
    }
    Node* temp = head;
    while(temp->next){
        temp = temp->next;
    }
    temp->next = newNode;
}

void printLL(Node* head){
    Node* temp = head;
    while(temp){
        cout << temp->data << "->";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

Node* insertionSortList(Node* head, int &cnt, int (*cmp)(int, int)) {
    if(!head || !head->next) return head;
    Node dummy;
    dummy.next = nullptr;
    Node* sorted = &dummy;
    Node* curr = head;
    while(curr){

        Node* nextNode = curr->next;
        Node*  prev = &dummy;
        while(prev->next && cmp(prev->next->data, curr->data) < 0) {
            cnt++;
            prev = prev->next;
        }
        curr->next = prev->next;
        prev->next = curr;
        curr = nextNode;
    }
    return dummy.next;
}

