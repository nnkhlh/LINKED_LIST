#include "Ex04.h"
using namespace std;

int main() {
    srand(time(0));
    int n = 50;
    int *a = new int[n];
    for (int i = 0; i < n; i++) {
        a[i] = 1 + rand() % 1000;
    }

    int cnt1 = 0;
    insertionSort(a, n, cnt1, cmp1);
    cout << "Comparisons in Array Sort: " << cnt1 << endl;
    cout << "Ascending order: " << endl;
    printArray(a, n);

    cnt1 = 0;
    insertionSort(a, n, cnt1, cmp2);
    cout << "\n\nComparisons in Array Sort: " << cnt1;
    cout << "\nDeascending order: " << endl;
    printArray(a, n);

    Node* head = NULL;
    for (int i = 0; i < n; i++) {
        insertNode(head, 1 + rand() % 1000);
    }
    int cnt2 = 0;
    Node* newList1 = insertionSortList(head, cnt2, cmp1);
    cout << "\n\nComparisons in Linked List Sort: " << cnt2 << endl;
    printLL(newList1);

    Node* newList2 = insertionSortList(newList1, cnt2, cmp2);
    cout << "\n\nComparisons in Linked List Sort: " << cnt2 << endl;
    printLL(newList2);

    delete []a;
    return 0;
}
