#include "Ex03.h"

long selectionSort(int a[], const int n, int (*cmp)(int, int)) {
    int vitrimin = 0;
    long comparisons = 0;
    for (int i = 0; i < n - 1; i++) {
        vitrimin = i;
        for (int j = i + 1; j < n; j++) {
            comparisons++;
            if (cmp(a[j], a[vitrimin]) < 0) {
                vitrimin = j;
            }
        }
        swap(a[i], a[vitrimin]);
    }
    return comparisons;
}

int selectionSortList(Node *head, int (*cmp)(int, int)) {
    if (!head) return 0;
    int comparisons = 0;
    for (Node* i = head; i != NULL; i = i->next) {
        Node* minNode = i;
        for (Node* j = i->next; j != NULL; j = j->next) {
            comparisons++;
            if (cmp(j->data, minNode->data) < 0) {
                minNode = j;
            }
        }
        if (minNode != i) {
            swap(i->data, minNode->data);
        }
    }
    return comparisons;
}

void insertNode(Node* &head, int val) {
    Node* newNode = new Node{val, head};
    head = newNode;
}

void printList(Node *head) {
    while (head) {
        cout << head->data << ' ';
        head = head->next;
    }
    cout << endl;
}

void printArray(int *a, int n) {
    for (int i = 0; i < n - 1; i++) {
        cout << a[i] << ' ';
    }
    cout << a[n - 1] << endl;
}

int cmp1(int a, int b) {
    return a - b;
}

int cmp2(int a, int b) {
    return b - a;
}

