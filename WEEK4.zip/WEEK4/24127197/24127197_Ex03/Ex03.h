#ifndef EX03_H
#define EX03_H

#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

struct Node {
    int data;
    Node* next;
};

void insertNode(Node* &head, int val);
void printList(Node *head);
long selectionSort(int a[], const int n, int (*cmp)(int, int));
int selectionSortList(Node *head, int (*cmp)(int, int));
void printArray(int *a, int n);
int cmp1(int a, int b);
int cmp2(int a, int b);

#endif


