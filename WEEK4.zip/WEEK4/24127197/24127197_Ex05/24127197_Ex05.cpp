#include <iostream>
#include <fstream>
#include <algorithm>
#include "Stack.h"
using namespace std;

int* readBinaryFile(const string &filename, int &size){
    ifstream fin(filename, ios::binary);
    if(!fin) {
        cerr << "Cannot open file!" << endl;
        size = 0;
        return NULL;
    }
    fin.read(reinterpret_cast<char*>(&size), sizeof(int));

    int *arr = new int[size];
    fin.read(reinterpret_cast<char*>(arr), size * sizeof(int));
    fin.close();
    return arr;
}

int partitionArray(int *a, int l, int r, int &cnt){
    int pivot = a[l + (r - l) / 2];
    int i = l, j = r;
    while(i <= j) {
        while(a[i] < pivot){
            i++;
            cnt++;
        }
        while(a[j] > pivot){
            j--;
            cnt++;
        }
        if(i <= j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    return i;
}
void quickSort(int *a, int l, int r, int &cnt){
    if(l >= r) return;
    int index = partitionArray(a, l, r, cnt);
    quickSort(a, l, index - 1, cnt);
    quickSort(a, index, r, cnt);
}

struct QParam{
    int l, r;
};

void quickSortNR(int *a, int &n, int &cnt) {
    Stack<QParam>* s = CreateStack<QParam>();
    QParam p = {0, n - 1};
    S_Push(s, p);

    while(!S_IsEmpty(s)) {
        p = S_Pop(s);
        int i = partitionArray(a, p.l, p.r, cnt);
        if(p.l < i - 1) {
            QParam leftPart = {p.l, i - 1};
            S_Push(s, leftPart);
        }
        if(p.r > i) {
            QParam rightPart = {i, p.r};
            S_Push(s, rightPart);
        }
    }
    S_Clear(s);
}
int main(){
    int n = 0;
    int *arr1 = readBinaryFile("10000n_LE.bin", n);
    int *arr2 = new int[n];
    copy(arr1, arr1 + n, arr2);
    //cout << "Number of elements: " << n << endl;

    int comparisonsRecursive = 0;
    quickSort(arr1, 0, n - 1, comparisonsRecursive);
    cout << "Recursive QuickSort comparisons: " << comparisonsRecursive << endl;

    int comparisonsNonRecursive = 0;
    quickSortNR(arr2, n, comparisonsNonRecursive);
    cout << "Non-Recursive QuickSort comparisons: " << comparisonsNonRecursive << endl;

    delete[] arr1;
    delete[] arr2;

    return 0;
}
