#ifndef EX06_H
#define EX06_H

#include <iostream>
#include <fstream>
using namespace std;

int* readBinaryFile(const string &filename, int &n);
void merge1(int *a, int na, int *b, int nb, int* c, int &cnt);
void mergeSort1(int *a, int n, int *buff, int &cnt);
void merge2(int *a, int start, int mid, int end, int &cnt);
void mergeSort2(int *a, int n, int &cnt);


#endif // EX06_H
