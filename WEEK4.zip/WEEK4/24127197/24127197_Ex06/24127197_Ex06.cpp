#include "Ex06.h"
using namespace std;

int main() {
    int n;
    int *a1 = readBinaryFile("10000n_LE.bin", n);
    int cnt1 = 0, cnt2 = 0;
    int *buff = new int[n];
    mergeSort1(a1, n, buff, cnt1);
    cout << "Merge Sort (Recursive) comparisons: " << cnt1 << endl;

    int *a2 = readBinaryFile("10000n_LE.bin", n);
    mergeSort2(a2, n, cnt2);
    cout << "Merge Sort (No recursive) comparisons: " << cnt2 << endl;
    delete []a1;
    delete []a2;
    delete []buff;
    return 0;
}
