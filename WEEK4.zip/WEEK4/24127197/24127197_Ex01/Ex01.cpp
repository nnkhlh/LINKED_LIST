#include "Ex01.h"
using namespace std;

void convertTextToBinary(const string &textFile, const string &binaryFile){
    ifstream fin(textFile);
    ofstream fout(binaryFile);
    if(!fin) return;
    if(!fout) return;
    long long n;
    fin >> n;
    fin.ignore();

    int *arr = new int[n];
    for(int i = 0; i < n; i++){
        fin >> arr[i];
        if(fin.peek() ==',') fin.ignore();
    }

    fout.write((char*)(&n), sizeof(n));
    fout.write((char*)(arr), n * sizeof(int));
    fin.close();
    fout.close();
    delete []arr;
    cout << "Finish to convert to " << binaryFile << endl;
}

void convertBinaryToText(const string &binaryFile, const string &textFile) {
    ifstream fin(binaryFile, ios::binary);
    ofstream fout(textFile);
    if(!fin) return;
    if(!fout) return;
    int n;
    fin.read((char*)(&n), sizeof(n));
    fout << n << endl;

    int *arr = new int[n];
    fin.read((char*)(arr), n * sizeof(int));
    for (int i = 0; i < n; i++){
        fout << arr[i] << ',';
    }
    fin.close();
    fout.close();
    delete []arr;
    cout << "Finish to convert to " << textFile << endl;
}

