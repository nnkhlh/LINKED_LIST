#ifndef EX01_H
#define EX01_H

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void convertTextToBinary(const string &textFile, const string &binaryFile);
void convertBinaryToText(const string &binaryFile, const string &textFile);

#endif // EX01_H
