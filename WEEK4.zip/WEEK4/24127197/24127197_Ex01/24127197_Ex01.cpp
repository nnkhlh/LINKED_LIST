#include "Ex01.h"
using namespace std;

int main() {
    convertTextToBinary("1000n.txt", "1000n.bin");
    convertBinaryToText("10000n_LE.bin", "10000n.txt");
    convertTextToBinary("100000nSorted.txt", "100000nSorted.bin");
    return 0;
}
