#include "Ex07.h"
using namespace std;

int main() {
    int n;
    int *a = readBinaryFile("10000n_LE.bin", n);
    Node* head = NULL;
    if(a) {
        cout << "Number of elements: " << n << endl;
        for(int i = 0; i < n; i++) {
            insertNode(head, a[i]);
        }
    }
    int cnt = 0;
    mergeSortList(head,cnt);
    cout << "MergeSort comparisons: " << cnt << endl;
    //printArray(head);
    delete []a;
    return 0;
}
