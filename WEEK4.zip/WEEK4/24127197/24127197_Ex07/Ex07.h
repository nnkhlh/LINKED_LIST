#ifndef EX07_H
#define EX07_H

#include <iostream>
#include <fstream>
using namespace std;

struct Node{
    int data;
    Node* next;
};

int* readBinaryFile(const string &filename, int &n);
void insertNode(Node* &head, int data);
Node* getMiddle(Node* head);
Node* mergeLL(Node* left, Node* right, int &cnt);
Node* mergeSortList(Node* &head, int &cnt);
void printArray(Node* head);

#endif
