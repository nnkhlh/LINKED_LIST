#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

/*int* readBinaryFile(const string &filename, int &size){
    ifstream fin(filename, ios::binary);
    if(!fin) {
        cerr << "Cannot open file!" << endl;
        size = 0;
        return NULL;
    }

    fin.read(reinterpret_cast<char*>(&size), sizeof(int));

    int *arr = new int[size];

    fin.read(reinterpret_cast<char*>(arr), size * sizeof(int));
    fin.close();
    return arr;
}*/

int* readBinaryFile(const string &filename, int &n) {
    ifstream fin(filename, ios::binary);
    if(!fin) {
        cout << "Cannot open file!" << endl;
        n = 0;
        return NULL;
    }
    fin.read(reinterpret_cast<char*>(&n), sizeof(int));
    int *arr = new int[n];
    fin.read(reinterpret_cast<char*>(arr), n * sizeof(int));
    return arr;
}

int partitionArray(int *a, int l, int r, int pivot){
    int i = l, j = r;
    while(i <= j) {
        while(a[i] < pivot) i++;
        while(a[j] > pivot) j--;
        if(i <= j) {
            swap(a[i], a[j]);
            i++;
            j--;
        }
    }
    return i;
}
void quickSort(int *a, int l, int r){
    if(l >= r) return;
    int pivot = a[l + (r - l) / 2];
    int index = partitionArray(a, l, r, pivot);
    quickSort(a, l, index - 1);
    quickSort(a, index, r);
}

/*void merge(int *a, int na, int* b, int nb, int *c) {
    int i = 0, j = 0, k = 0;
    while(i < na && j < nb) {
        if(a[i] <= b[j]) c[k++] = a[i++];
        else c[k++] = b[j++];
    }
    while(i < na) c[k++] = a[i++];
    while(j < nb) c[k++] = b[j++];
}

void mergeSort(int *a, int n, int *buff) {
    if(n <= 1) return;
    int half = n / 2;
    mergeSort(a, half, buff);
    mergeSort(a + half, n - half, buff);
    merge(a, half, a + half, n - half, buff);
    copy(buff, buff + n, a);
}*/
int main(){
    int n = 0;
    int *arr = readBinaryFile("10000n_LE.bin", n);
    cout << "Number of elements: " << n << endl;
    int* buff = new int[n];
    quickSort(arr, 0, n - 1);
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
    delete[] arr;
    delete[] buff;
    return 0;
}
