/*#include <iostream>
#include <fstream>
#include <sys/stat.h>

using namespace std;

long long getFileSize(const string &filename) {
    struct stat stat_buf;
    if (stat(filename.c_str(), &stat_buf) == 0) {
        return stat_buf.st_size;
    }
    return -1;
}

int main() {
    string filename = "100000nSorted.txt";
    long long size = getFileSize(filename);

    if (size == -1) {
        cerr << "Không thể lấy kích thước file!" << endl;
    } else {
        cout << "FILE SIZE: " << size << " bytes" << endl;
    }
    return 0;
}
*/
#include <iostream>
#include <fstream>

using namespace std;

void convertLargeTextToBinary(const string &textFile, const string &binaryFile) {
    ifstream fin(textFile);
    ofstream fout(binaryFile, ios::binary);

    if (!fin) {
        cerr << "Không thể mở file văn bản: " << textFile << endl;
        return;
    }
    if (!fout) {
        cerr << "Không thể tạo file nhị phân: " << binaryFile << endl;
        return;
    }

    int n = 0;
    string numStr;
    streampos startPos = fin.tellg(); // Lưu vị trí ban đầu

    // **Bước 1: Đếm số lượng phần tử**
    while (getline(fin, numStr, ',')) {
        n++;  // Mỗi số cách nhau bằng dấu ','
    }

    // Ghi số lượng phần tử vào file nhị phân
    fout.write(reinterpret_cast<char*>(&n), sizeof(n));

    // **Bước 2: Đọc lại từng số và ghi vào file nhị phân**
    fin.clear();  // Xóa trạng thái lỗi của ifstream
    fin.seekg(startPos, ios::beg); // Quay về đầu file để đọc số

    int num;
    while (getline(fin, numStr, ',')) {
        num = stoi(numStr); // Chuyển đổi từ chuỗi sang số nguyên
        fout.write(reinterpret_cast<char*>(&num), sizeof(num)); // Ghi từng số vào file nhị phân
    }

    fin.close();
    fout.close();
    cout << "finish to" << binaryFile << endl;
}

int main() {
    convertLargeTextToBinary("100000nSorted.txt", "100000nSorted.bin");
    return 0;
}
