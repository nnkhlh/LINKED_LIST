#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

void convertTextToBinary1(const string &textFile, const string &binaryFile) {
    ifstream fin(textFile);
    ofstream fout(binaryFile, ios::binary);
    if(!fin){
        cerr << "Cannot open file!" << endl;
        return;
    }
    if(!fout) {
        cerr << "Cannot create Binary File!" << endl;
        return;
    }

    int n;
    fin >> n;
    fin.ignore(); //bỏ qua kí tự xuống dòng sau số lượng phần tử

    vector<long long> nums;
    string numstr;

    while(getline(fin, numstr, ',')) {
        nums.push_back(stoi(numstr)); //chuyển từ chuỗi thành số
    }
    // Ghi số lượng phần tử vào file nhị phân
    fout.write(reinterpret_cast<char*>(&n), sizeof(int));
    //ghi mảng vào file
    fout.write(reinterpret_cast<char*>(&nums[0]), n * sizeof(int));

    fin.close();
    fout.close();
    cout << "Finish to convert to " << binaryFile << endl;
}
void convertTextToBinary2(const string &textFile, const string &binaryFile){
    ifstream fin(textFile);
    ofstream fout(binaryFile);
    if(!fin) return;
    if(!fout) return;
    long long n;
    fin >> n;
    fin.ignore();

    int *arr = new int[n];
    for(int i = 0; i < n; i++){
        fin >> arr[i];
        if(fin.peek() ==',') fin.ignore();
    }

    fout.write(reinterpret_cast<char*> (&n), sizeof(n));
    fout.write(reinterpret_cast<char*> (arr), n * sizeof(int));
    fin.close();
    fout.close();
    delete []arr;
    cout << "Finish to convert to " << binaryFile << endl;
}
void convertBinaryToText1(const string &binaryFile, const string &textFile){
    ifstream fin(binaryFile, ios::binary);
    ofstream fout(textFile);
    if(!fin){
        cerr << "Cannot open file!" << endl;
        return;
    }
    if(!fout) {
        cerr << "Cannot create Binary File!" << endl;
        return;
    }
    int n;
    fin.read(reinterpret_cast<char*>(&n), sizeof(n));
    vector<int> nums(n);
    fin.read(reinterpret_cast<char*>(&nums[0]), n * sizeof(int));
    fin.close();
    fout << n << endl;
    for (int i = 0; i < nums.size(); i++) {
        fout << nums[i] << ',';
    }
    fout.close();
    cout << "Finish to convert to " << textFile << endl;
}

void convertBinaryToText2(const string &binaryFile, const string &textFile) {
    ifstream fin(binaryFile, ios::binary);
    ofstream fout(textFile);
    if(!fin) return;
    if(!fout) return;
    int n;
    fin.read(reinterpret_cast<char*>(&n), sizeof(n));
    fout << n << endl;

    int *arr = new int[n];
    fin.read(reinterpret_cast<char*>(arr), n * sizeof(int));
    for (int i = 0; i < n; i++){
        fout << arr[i] << ',';
    }
    fin.close();
    fout.close();
    delete []arr;
    cout << "Finish to convert to " << textFile << endl;
}
/*void convertLargeTextToBinary(const string &textFile, const string &binaryFile) {
    ifstream fin(textFile);
    ofstream fout(binaryFile, ios::binary);

    if(!fin){
        cerr << "Cannot open file!" << endl;
        return;
    }
    if(!fout) {
        cerr << "Cannot create Binary File!" << endl;
        return;
    }

    int n = 0;
    string numStr;
    streampos startPos = fin.tellg(); // Lưu vị trí ban đầu

    // **Bước 1: Đếm số lượng phần tử**
    while (getline(fin, numStr, ',')) {
        n++;  // Mỗi số cách nhau bằng dấu ','
    }

    // Ghi số lượng phần tử vào file nhị phân
    fout.write(reinterpret_cast<char*>(&n), sizeof(n));

    // **Bước 2: Đọc lại từng số và ghi vào file nhị phân**
    fin.clear();  // Xóa trạng thái lỗi của ifstream
    fin.seekg(startPos, ios::beg); // Quay về đầu file để đọc số

    int num;
    while (getline(fin, numStr, ',')) {
        num = stoi(numStr); // Chuyển đổi từ chuỗi sang số nguyên
        fout.write(reinterpret_cast<char*>(&num), sizeof(num)); // Ghi từng số vào file nhị phân
    }

    fin.close();
    fout.close();
    cout << "Finish to convert to " << binaryFile << endl;
}*/

int main() {
    convertTextToBinary2("1000n.txt", "1000n.bin");
    convertBinaryToText2("10000n_LE.bin", "10000n.txt");
    convertTextToBinary2("100000nSorted.txt", "100000nSorted.bin");
    return 0;
}
